import React from "react";

const Sold = () => {
	return <div>Sold</div>;
};

export default Sold;
