import React from "react";

const ForSale = () => {
	return <div>For Sale</div>;
};

export default ForSale;
